from pathlib import Path
import json,math,re,ast,shutil
R=Path('.');S=R/'build/iceologer-v24/research';P=R/'resourcepack';O=R/'updates/iceologer-v24';O.mkdir(parents=True,exist_ok=True)
g=json.loads((S/'geo_illager.geo.json').read_text())['minecraft:geometry'][0];animations=json.loads((S/'iceologer.animation.json').read_text())['animations'];visible={'bipedLegLeft','bipedLegRight','bipedBody','bipedArmLeft','bipedArmRight','bipedHead'}
# Evaluate only the arithmetic and trigonometry present in this pinned source; no eval/Molang execution on the server.
def expression(value,t):
 if isinstance(value,(int,float)):return float(value)
 value=value.replace('query.anim_time','t').replace('query.ground_speed','1.0').replace('Math.cos','cos').replace('Math.clamp','clamp')
 def visit(n):
  if isinstance(n,ast.Constant)and isinstance(n.value,(int,float)):return n.value
  if isinstance(n,ast.Name)and n.id=='t':return t
  if isinstance(n,ast.UnaryOp)and isinstance(n.op,(ast.USub,ast.UAdd)):return (-1 if isinstance(n.op,ast.USub)else 1)*visit(n.operand)
  if isinstance(n,ast.BinOp)and isinstance(n.op,(ast.Add,ast.Sub,ast.Mult,ast.Div)):
   a,b=visit(n.left),visit(n.right);return {ast.Add:lambda:a+b,ast.Sub:lambda:a-b,ast.Mult:lambda:a*b,ast.Div:lambda:a/b}[type(n.op)]()
  if isinstance(n,ast.Call)and isinstance(n.func,ast.Name)and not n.keywords:
   a=[visit(v)for v in n.args]
   if n.func.id=='cos'and len(a)==1:return math.cos(math.radians(a[0]))
   if n.func.id=='clamp'and len(a)==3:return max(a[1],min(a[2],a[0]))
  raise ValueError(ast.dump(n))
 return visit(ast.parse(value,mode='eval').body)
def vector(v,t):return [expression(x,t)for x in(v['vector']if isinstance(v,dict)else v)]
def channel(clip,bone,prop,t):
 d=animations[clip]['bones'].get(bone,{}).get(prop)
 if d is None:return [1,1,1]if prop=='scale'else[0,0,0]
 if isinstance(d,list)or'vector'in d:return vector(d,t)
 keys=sorted((float(k),v)for k,v in d.items())
 if t<=keys[0][0]:return vector(keys[0][1],t)
 for(a,v),(b,w)in zip(keys,keys[1:]):
  if t<=b:
   f=(t-a)/(b-a);e=w.get('easing','linear');assert e in ['linear','easeInOutSine'];f=-(math.cos(math.pi*f)-1)/2 if e=='easeInOutSine'else f
   return [x+(y-x)*f for x,y in zip(vector(v,t),vector(w,t))]
 return vector(keys[-1][1],t)
def run():
 rig=[]
 for bone in g['bones']:
  b=dict(bone)
  if b['name']not in visible:b.pop('cubes',None)
  rig.append(b)
  if b['name']not in visible:continue
  px,py,pz=b['pivot'];elements=[]
  for c in b['cubes']:
   assert'rotation'not in c;x,y,z=c['origin'];dx,dy,dz=c['size'];i=c.get('inflate',0);u,v=c['uv'];uv={'east':[u,v+dz,u+dz,v+dz+dy],'south':[u+dz,v+dz,u+dz+dx,v+dz+dy],'west':[u+dz+dx,v+dz,u+2*dz+dx,v+dz+dy],'north':[u+2*dz+dx,v+dz,u+2*dz+2*dx,v+dz+dy],'up':[u+dz,v,u+dz+dx,v+dz],'down':[u+dz+dx,v,u+dz+2*dx,v+dz]}
   elements.append({'from':[-x-dx+px+8-i,y-py+8-i,-z-dz+pz+8-i],'to':[-x+px+8+i,y+dy-py+8+i,-z+pz+8+i],'faces':{f:{'uv':[n/4 for n in a],'texture':'#mob',**({'rotation':180}if f in['up','down']else{})}for f,a in uv.items()}})
  assert all(-16<=v<=32 for e in elements for k in['from','to']for v in e[k])
  for kind,doc in [('models',{'credit':'Dungeons Mobs contributors / MIT; teash display conversion','textures':{'mob':'teash:item/mobs/iceologer','particle':'teash:item/mobs/iceologer'},'ambientocclusion':False,'elements':elements}),('items',{'model':{'type':'minecraft:model','model':'teash:mobs/iceologer-'+b['name'].lower()}})]:
   f=P/f"assets/teash/{kind}/mobs/iceologer-{b['name'].lower()}.json";f.parent.mkdir(parents=True,exist_ok=True);f.write_text(json.dumps(doc,indent=2))
 (R/'plugins-src/teash-testmobs/iceologer-rig.json').write_text(json.dumps(rig,indent=2))
 baked={}
 for short,length in [('idle',2.4),('walk',1.2),('summon',3)]:
  source='iceologer_'+short;clip={'loop':short!='summon','animation_length':length,'bones':{}}
  for name,props in animations[source]['bones'].items():
   clip['bones'][name]={p:{f'{frame/60:.8f}':{'vector':channel(source,name,p,frame/60)}for frame in range(round(length*60)+1)}for p in props}
  baked[short]=clip
 (R/'plugins-src/teash-testmobs/iceologer-animations.json').write_text(json.dumps({'animations':baked},separators=(',',':')))
 shutil.copyfile(S/'iceologer.png',P/'assets/teash/textures/item/mobs/iceologer.png')
 # Use native illager sounds rather than importing potentially third-party audio recordings.
 license=P/'licenses/dungeons-mobs-iceologer';license.mkdir(parents=True,exist_ok=True)
 for name in ['LICENSE.txt','IceologerModel.java','IceologerEntity.java','geo_illager.geo.json','iceologer.animation.json','iceologer.png','source.json']:shutil.copyfile(S/name,license/name)
 shutil.copyfile(__file__,license/'import-iceologer-v24.py');(license/'NOTICE.txt').write_text('Iceologer model and animation: Dungeons Mobs contributors, MIT. Copyright (c) 2022 Patrigan.\nhttps://github.com/Infamous-Misadventures/Dungeons-Mobs/tree/f04b11e7b3672776599fd15ad98a61c53f63b182\nChanges by teash: six visible body parts, native display conversion, sampled source Molang at 60 Hz (walk normalized to actual travelled distance), vanilla illager sounds, independent server AI. Equipment placeholders and folded arms hidden as in the source renderer. No official Mojang Java model is implied.\n')
 print(json.dumps({'parts':sorted(visible),'clips':list(baked)}))
if __name__=='__main__':run()
