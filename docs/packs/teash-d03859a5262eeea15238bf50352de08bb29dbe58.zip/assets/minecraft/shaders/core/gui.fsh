#version 330

// Can't moj_import in things used during startup, when resource packs don't exist.
// This is a copy of dynamicimports.glsl
layout(std140) uniform DynamicTransforms {
    mat4 ModelViewMat;
    vec4 ColorModulator;
    vec3 ModelOffset;
    mat4 TextureMat;
};

in vec4 vertexColor;
in float holdOutline;

out vec4 fragColor;

void main() {
    vec4 color = vertexColor;
    // holdOutline interpolates to 1 only inside a quad whose every corner the vertex stage flagged.
    if (color.a == 0.0 || holdOutline > 0.999) {
        discard;
    }
    fragColor = color * ColorModulator;
}
