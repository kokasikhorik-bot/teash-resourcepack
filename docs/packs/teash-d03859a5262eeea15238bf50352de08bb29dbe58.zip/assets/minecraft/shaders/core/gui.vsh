#version 330

// Can't moj_import in things used during startup, when resource packs don't exist.
// This is a copy of dynamicimports.glsl and projection.glsl
layout(std140) uniform DynamicTransforms {
    mat4 ModelViewMat;
    vec4 ColorModulator;
    vec3 ModelOffset;
    mat4 TextureMat;
};
layout(std140) uniform Projection {
    mat4 ProjMat;
};

in vec3 Position;
in vec4 Color;

out vec4 vertexColor;
out float holdOutline;

// A dialog body message is a FocusableTextWidget: a click focuses it and the client outlines its
// bounds in opaque white, four 1px fills. The hold navigator's bounds are fixed by the dialog layout:
// the body's declared width by lines*9+8, centred, top at header 33 + 30 while the screen is tall
// enough not to scroll. A pure white quad with every corner on that frame is the outline and nothing
// else on the network draws one there; the fragment stage drops it. Body geometry is owned by Nucleus
// GlyphNavComposer (BODY_WIDTH, 23 lines) and must change together with these constants.
const float OUTLINE_W = 266.0;
const float OUTLINE_H = 215.0;
const float HEADER = 33.0;
const float FOOTER = 33.0;
const float CONTENT_TOP = HEADER + 30.0;

bool on(float v, float edge) {
    return abs(v - edge) < 0.01;
}

void main() {
    vec4 pos = ModelViewMat * vec4(Position, 1.0);
    gl_Position = ProjMat * pos;
    vertexColor = Color;

    holdOutline = 0.0;
    // ProjMat[3][3] == 1 only for the orthographic GUI pass.
    if (ProjMat[3][3] > 0.5 && all(greaterThan(Color, vec4(254.5 / 255.0)))) {
        float guiW = 2.0 / ProjMat[0][0];
        float guiH = -2.0 / ProjMat[1][1];
        float x0 = floor((guiW - OUTLINE_W) * 0.5 + 0.01);
        float bodyH = min(OUTLINE_H, guiH - HEADER - FOOTER);
        float y0 = min(CONTENT_TOP, guiH - FOOTER - bodyH);
        bool onX = on(pos.x, x0) || on(pos.x, x0 + 1.0)
            || on(pos.x, x0 + OUTLINE_W - 1.0) || on(pos.x, x0 + OUTLINE_W);
        bool onY = on(pos.y, y0) || on(pos.y, y0 + 1.0)
            || on(pos.y, y0 + OUTLINE_H - 1.0) || on(pos.y, y0 + OUTLINE_H);
        if (onX && onY) {
            holdOutline = 1.0;
        }
    }
}
