"""Detailed multipart assets; preserve ordinary items and sprite atlas fixes."""
from pathlib import Path
from io import BytesIO
import zipfile,json,hashlib,copy,math,re,random
from PIL import Image,ImageDraw,ImageFont
out=Path('updates/admin-v3');out.mkdir(parents=True,exist_ok=True)
base=Path('updates/admin-v2/teash-resourcepack.zip');assert hashlib.sha1(base.read_bytes()).hexdigest()=='08458dcb762cf425a48f85e7380125475d052cad'
with zipfile.ZipFile(base)as z:files={n:z.read(n)for n in z.namelist()if not n.endswith('/')}
before=dict(files);blueprints={};stats={};root=Path('resourcepack')
def put(n,obj):files[n]=json.dumps(obj,ensure_ascii=False,separators=(',',':')).encode()
def png(n,im):buf=BytesIO();im.save(buf,format='PNG');files[n]=buf.getvalue()
def define(name,ref):put('assets/teash/items/admin/'+name+'.json',{'model':{'type':'minecraft:model','model':ref}})
def export(name,model):
 put('assets/teash/models/item/admin/detail/'+name+'.json',model);define('detail/'+name,'teash:item/admin/detail/'+name);stats[name]=len(model.get('elements',[]))
def euler(point,r):
 x,y,z=point;rx,ry,rz=map(math.radians,r)
 y,z=y*math.cos(rx)-z*math.sin(rx),y*math.sin(rx)+z*math.cos(rx)
 x,z=x*math.cos(ry)+z*math.sin(ry),-x*math.sin(ry)+z*math.cos(ry)
 x,y=x*math.cos(rz)-y*math.sin(rz),x*math.sin(rz)+y*math.cos(rz)
 return[x,y,z]
def element_point(p,r):
 if not r:return p
 angle=[0,0,0];angle['xyz'.index(r['axis'])]=r['angle'];o=r['origin'];v=euler([a-b for a,b in zip(p,o)],angle);return[a+b for a,b in zip(v,o)]
def source_part(name,source,center,size,rotation=(0,0,0),spin='',aim=False):
 path=f'assets/bettermodel/models/modern_item/{source}.json';d=json.loads((root/path).read_text());d.pop('display',None)
 # The resource pack contains baked bone models, not their skeleton. Assemble them with explicit mounts.
 points=[]
 for element in d['elements']:
  for bits in range(8):
   p=element_point([element['to'if bits>>i&1 else'from'][i]for i in range(3)],element.get('rotation'));points.append(euler([v-8 for v in p],rotation))
 lo=[min(p[i]for p in points)for i in range(3)];hi=[max(p[i]for p in points)for i in range(3)];scale=min(size[i]*16/(hi[i]-lo[i])for i in range(3)if hi[i]-lo[i]>.001);offset=[center[i]-(hi[i]+lo[i])/2*scale/16 for i in range(3)]
 export(name,d)
 for texture in d['textures'].values():
  if texture.startswith('#'):continue
  ns,p=texture.split(':');n=f'assets/{ns}/textures/{p}.png'
  if n not in files:files[n]=(root/n).read_bytes()
 return{'name':name,'model':'detail/'+name,'offset':offset,'rotation':list(rotation),'scale':scale,'spin':spin,'aim':aim}
heli=[]
heli.append(source_part('heli_fuselage','helicopter_body2_7',[0,0,0],[3.6,1.8,6.6]))
heli.append(source_part('heli_canopy','helicopter_cockpit_1',[0,.15,-2.3],[1.9,1.35,2.05],[49,0,0]))
heli.append(source_part('heli_tail','helicopter_back_1',[0,.65,3.35],[.45,1.55,1.3],[25,0,0]))
for side,x in [('left',-1.55),('right',1.55)]:heli.append(source_part('heli_pod_'+side,'helicopter_'+side+'_1',[x,-.45,-.25],[1.2,.9,1.6]))
for i,(x,z)in enumerate([(-1.1,-1.8),(1.1,-1.8),(-1.1,1.75),(1.1,1.75)]):heli.append(source_part('heli_wheel_'+str(i),'helicopter_left2_2',[x,-1.15,z],[.45,.6,.6]))
heli.append(source_part('heli_rotor_hub','helicopter_rotor1_1',[0,1.2,0],[.8,.8,.8]))
heli.append(source_part('heli_rotor','helicopter_rotor2_1',[0,1.65,0],[7,.08,7],[0,0,90],spin='y'))
heli.append(source_part('heli_tail_rotor','helicopter_rotor2_1',[-.28,.7,3.55],[.08,1.5,1.5],spin='x'))
heli.append(source_part('heli_gun','helicopter_machinegun_1',[0,-.7,-2.5],[.5,.6,1.6],aim=True))
blueprints['helicopter']={'forward':'-z','parts':heli}
define('helicopter','teash:item/admin/detail/heli_fuselage')

# Weathered steel, carbon weave, rubber and brass. Actual texture tiles, not single-color cubes.
palette={'steel':(88,95,99),'dark':(29,32,35),'carbon':(38,41,43),'rubber':(18,20,21),'glass':(52,83,95),'olive':(83,88,63),'red':(124,47,40),'brass':(149,122,69),'wood':(88,62,41),'white':(176,179,172)}
atlas=Image.new('RGBA',(128,128));draw=ImageDraw.Draw(atlas);rng=random.Random(93271);tile={}
for i,(name,color)in enumerate(palette.items()):
 x,y=i%4*32,i//4*32;tile[name]=[x/8,y/8,(x+32)/8,(y+32)/8]
 for yy in range(32):
  for xx in range(32):
   noise=rng.randint(-7,7);noise+=(5 if(xx//2+yy//2)%2 else-5)if name=='carbon'else 0;noise+=(yy%5-2)*3 if name=='wood'else 0;atlas.putpixel((x+xx,y+yy),tuple(max(0,min(255,v+noise))for v in color)+(255,))
 if name in['steel','olive','dark']:draw.rectangle((x+1,y+1,x+30,y+30),outline=tuple(max(0,v-20)for v in color));draw.point((x+3,y+3),fill='#c3c7c4');draw.point((x+28,y+28),fill='#b2b5af')
png('assets/teash/textures/admin/detail/materials.png',atlas)
def cube(a,b,material,rotation=None):
 e={'from':a,'to':b,'faces':{side:{'texture':'#all','uv':tile[material]}for side in['north','south','east','west','up','down']}}
 if rotation:e['rotation']=rotation
 return e
def standard(parts):return{'textures':{'all':'teash:admin/detail/materials','particle':'teash:admin/detail/materials'},'elements':parts,'display':{'gui':{'rotation':[20,38,0],'scale':[.7,.7,.7]},'firstperson_righthand':{'rotation':[0,-30,0],'translation':[0,2,0],'scale':[.55,.55,.55]},'thirdperson_righthand':{'translation':[0,2,0],'scale':[.55,.55,.55]}}}
def cylinder(center,radius,length,axis,material):
 parts=[]
 for angle in[0,45]:
  half=radius/(math.sqrt(2)if angle else 1);a=[center[i]-half for i in range(3)];b=[center[i]+half for i in range(3)];index='xyz'.index(axis);a[index]=center[index]-length/2;b[index]=center[index]+length/2
  parts.append(cube(a,b,material,{'origin':center,'axis':axis,'angle':angle}if angle else None))
 return parts
# Correct the main rotor spindle and connect the landing wheels to the fuselage.
mast=cylinder([8,8,8],2,8,'y','steel')+cylinder([8,12,8],3,1.5,'y','dark');export('heli_mast',standard(mast))
blueprints['helicopter']['parts']=[p for p in heli if p['name']!='heli_rotor_hub']+[{'name':'mast','model':'detail/heli_mast','offset':[0,1.25,0],'scale':1,'rotation':[0,0,0]}]
export('heli_landing_strut',standard([cube([7.4,4,7.4],[8.6,12,8.6],'steel')]))
for i,(x,z)in enumerate([(-1.1,-1.8),(1.1,-1.8),(-1.1,1.75),(1.1,1.75)]):blueprints['helicopter']['parts'].append({'name':'strut_'+str(i),'model':'detail/heli_landing_strut','offset':[x,-.8,z],'scale':1,'rotation':[0,0,0]})
drone=[cube([5,7,3],[11,8,13],'carbon'),cube([5.3,8.1,4],[10.7,8.5,12],'carbon'),cube([5.8,8.5,5],[10.2,11,11],'dark'),cube([6.1,11,5.4],[9.9,11.4,10.6],'olive'),cube([6.7,8.8,4.6],[7.3,11.7,11.4],'rubber'),cube([8.7,8.8,4.6],[9.3,11.7,11.4],'rubber'),cube([6.6,7.5,1.4],[9.4,10.2,4],'steel')]
drone+=cylinder([8,8.7,1.1],1,.5,'z','glass')
for x,z in[(1,1),(15,1),(1,15),(15,15)]:
 angle=45 if x==z else-45;drone.append(cube([7.5,7.2,0],[8.5,7.8,16],'carbon',{'origin':[8,7.5,8],'axis':'y','angle':angle}));drone+=cylinder([x,8,z],1.2,1.7,'y','steel');drone+=cylinder([x,8.9,z],1.05,.35,'y','dark');drone.append(cube([x-.25,9.2,z-.25],[x+.25,9.6,z+.25],'brass'))
for side,x in[('a',4.8),('b',11.2)]:drone.append(cube([x,5.7,6],[x+.35,7.2,10],'steel'))
drone+=cylinder([8,5.8,8],1.4,6,'z','olive');drone.append(cube([7.7,8,12],[8.3,13.5,12.5],'rubber'))
export('fpv_frame',standard(drone));rotor=standard([cube([2,7.85,7.5],[14,8.15,8.5],'dark'),cube([7.5,7.85,2],[8.5,8.15,14],'dark')]);export('fpv_rotor',rotor)
droneparts=[{'name':'frame','model':'detail/fpv_frame','offset':[0,0,0],'scale':.9,'rotation':[0,0,0]}]
for i,(x,z)in enumerate([(1,1),(15,1),(1,15),(15,15)]):droneparts.append({'name':'blade_'+str(i),'model':'detail/fpv_rotor','offset':[(x-8)/16*.9,1.25/16*.9,(z-8)/16*.9],'scale':.9,'rotation':[0,0,0],'spin':'y'})
blueprints['drone']={'forward':'-z','parts':droneparts};define('drone','teash:item/admin/detail/fpv_frame')

bomb=[]
for y,r,length,mat in[(1,.7,2,'steel'),(3,1.2,2,'olive'),(6,1.65,4,'olive'),(10,1.65,4,'olive'),(13,1.2,2,'steel'),(15,.7,2,'steel')]:bomb+=cylinder([8,y,8],r,length,'y',mat)
for angle in[0,45]:bomb.append(cube([4,12,7.8],[12,16,8.2],'steel',{'origin':[8,14,8],'axis':'y','angle':angle}))
bomb.append(cube([6.35,8,6.35],[9.65,8.5,9.65],'brass'));export('bomb',standard(bomb));define('bomb','teash:item/admin/detail/bomb')
rocket=[]
for z,r,length,mat in[(1,.3,2,'steel'),(3,.65,2,'steel'),(7,.9,6,'olive'),(12,.8,4,'olive'),(15,.45,2,'dark')]:rocket+=cylinder([8,8,z],r,length,'z',mat)
for angle in[0,45]:rocket.append(cube([5.6,7.8,12],[10.4,8.2,16],'steel',{'origin':[8,8,14],'axis':'z','angle':angle}))
export('rocket',standard(rocket));define('rocket','teash:item/admin/detail/rocket')

# B-2 inspired flying wing: a complete 3D silhouette, not a sprite of a biplane.
plane=[cube([6,7,2],[10,8.7,15],'dark'),cube([6.8,8.7,3],[9.2,9.3,6],'glass'),cube([7.5,7.4,0],[8.5,8,3],'steel')]
for side in[-1,1]:
 for i in range(7):
  cx=8+side*(2.5+i*1.35);z=5+i*.72;width=1.8;plane.append(cube([cx-width/2,7.5-i*.04,z],[cx+width/2,8.1-i*.04,15-i*.4],'dark'))
 for i in range(2):plane+=cylinder([8+side*(2+i*.8),7.9,12.5],.35,3,'z','steel')
export('stealth_plane',standard(plane));define('plane','teash:item/admin/detail/stealth_plane');define('bomber','teash:item/admin/detail/stealth_plane');blueprints['bomber']={'forward':'-z','parts':[{'name':'airframe','model':'detail/stealth_plane','offset':[0,0,0],'scale':9,'rotation':[0,0,0]}]}

for name,headmat in[('ban_hammer','steel'),('shark_hammer','dark')]:
 hammer=[cube([7.3,-2,7.3],[8.7,15,8.7],'wood'),cube([7.15,-2,7.15],[8.85,-.5,8.85],'steel')]
 for y in range(1,11,2):hammer.append(cube([7.1,y,7.1],[8.9,y+.7,8.9],'rubber'))
 hammer+=cylinder([8,16,8],3.2,11,'x',headmat)
 for x in[2.3,12.9]:hammer+=cylinder([x,16,8],3.4,.8,'x','steel')
 if name=='shark_hammer':
  hammer.append(cube([7.8,18.3,6],[8.2,22,9],'steel',{'origin':[8,18.3,8],'axis':'x','angle':-22.5}))
  for z in[5.5,7,8.5,10]:hammer.append(cube([2,14,z],[3,15,z+.6],'white'))
 else:
  hammer.append(cube([5.7,18.4,6.5],[10.3,18.8,9.5],'brass'));hammer.append(cube([7.8,13.3,5],[8.2,18.6,5.3],'red'))
 export(name,standard(hammer));define(name,'teash:item/admin/detail/'+name)

# Original Untamed Wilds skeleton and texture, GPL-3.0. Convert the original cuboids and UVs.
source_root=out/'research/untamedwilds';java=(source_root/'src/main/java/untamedwilds/client/model/ModelShark.java').read_text();constructor=java.split('public ModelShark() {',1)[1].split('animator =',1)[0]
def nums(s):return[float(v.strip().removesuffix('F').removesuffix('f'))for v in s.split(',')]
bones={}
for name,u,v in re.findall(r'this\.(\w+) = new AdvancedModelBox\(this, (\d+), (\d+)\);',constructor):
 if name in['head_hammer','head_nose']:continue
 pos=nums(re.search(r'this\.'+name+r'\.setRotationPoint\(([^)]+)\)',constructor)[1]);box=nums(re.search(r'this\.'+name+r'\.addBox\(([^)]+)\)',constructor)[1]);rot=re.search(r'this\.setRotateAngle\('+name+r', ([^)]+)\)',constructor);r=nums(rot[1])if rot else[0,0,0]
 if name=='body_main':pos=[0,0,0];r=[0,0,0]
 parent=next((parent for parent,child in re.findall(r'this\.(\w+)\.addChild\(this\.(\w+)\)',constructor)if child==name),None)
 x,y,z,dx,dy,dz=box[:6];u,v=float(u),float(v);rects={'west':[u,v+dz,u+dz,v+dz+dy],'north':[u+dz,v+dz,u+dz+dx,v+dz+dy],'east':[u+dz+dx,v+dz,u+2*dz+dx,v+dz+dy],'south':[u+2*dz+dx,v+dz,u+2*dz+2*dx,v+dz+dy],'up':[u+dz,v,u+dz+dx,v+dz],'down':[u+dz+dx,v,u+dz+2*dx,v+dz]}
 el={'from':[x+8,-(y+dy)+8,z+8],'to':[x+dx+8,-y+8,z+dz+8],'faces':{face:{'texture':'#all','uv':[a/8 if i%2==0 else a/4 for i,a in enumerate(uv)]}for face,uv in rects.items()}}
 if name=='fin_left' or name=='fin_pelvic_left':
  for face in el['faces'].values():face['uv'][0],face['uv'][2]=face['uv'][2],face['uv'][0]
 export('shark_'+name,{'textures':{'all':'teash:admin/detail/shark_great_white'},'elements':[el]})
 bones[name]={'name':name,'parent':parent,'model':'detail/shark_'+name,'position':[pos[0]/16,-pos[1]/16,pos[2]/16],'rotation':[-r[0],r[1],-r[2]]}
files['assets/teash/textures/admin/detail/shark_great_white.png']=(source_root/'src/main/resources/assets/untamedwilds/textures/entity/shark/great_white.png').read_bytes()
blueprints['shark']={'forward':'-z','skeletonScale':3.4,'bones':list(bones.values())}
files['licenses/teash-admin-shark/LICENSE.md']=(source_root/'LICENSE.md').read_bytes();files['licenses/teash-admin-shark/ModelShark.java']=java.encode();files['licenses/teash-admin-shark/conversion.py']=Path(__file__).read_bytes();put('licenses/teash-admin-shark/converted-skeleton.json',blueprints['shark']);files['licenses/teash-admin-shark/README.txt']=b'Original model and texture: RayTrace082 / Untamed Wilds, GPL-3.0. https://github.com/RayTrace082/untamedwilds/tree/1.18.2\nAdapted to multipart ItemDisplay assets for teash. Original hierarchy and UVs retained. Hammerhead and goblin-only head parts omitted.\n'
put('assets/teash/admin-rigs.json',blueprints)
(out/'rigs.json').write_text(json.dumps(blueprints,indent=2));(out/'model-statistics.json').write_text(json.dumps(stats,indent=2))
atlas_path='assets/minecraft/atlases/items.json';item_atlas=json.loads(files[atlas_path]);registered={s['resource']for s in item_atlas['sources']if s['type']=='minecraft:single'}
for name,b in list(files.items()):
 if not name.startswith('assets/teash/models/item/admin/')or not name.endswith('.json'):continue
 for ref in json.loads(b).get('textures',{}).values():
  if ref.startswith('#'):continue
  ns,path=ref.split(':',1)if':'in ref else('minecraft',ref)
  if not path.startswith(('block/','item/'))and ref not in registered:item_atlas['sources'].append({'type':'minecraft:single','resource':ref});registered.add(ref)
put(atlas_path,item_atlas)
for name,b in files.items():
 if before.get(name)!=b and name in before:assert name==atlas_path or name.startswith(('assets/teash/items/admin/','assets/teash/models/item/admin/'))
with zipfile.ZipFile(out/'teash-resourcepack.zip','w',zipfile.ZIP_DEFLATED,compresslevel=6)as z:
 for name,b in files.items():z.writestr(name,b)
audit={'ok':True,'baseSha1':hashlib.sha1(base.read_bytes()).hexdigest(),'sha1':hashlib.sha1((out/'teash-resourcepack.zip').read_bytes()).hexdigest(),'changedFiles':[n for n in before if files[n]!=before[n]],'addedFiles':sorted(set(files)-set(before)),'modelParts':len(stats),'cuboids':sum(stats.values()),'helicopterParts':len(heli),'sharkBones':len(bones),'ordinaryResourcesUnchanged':True,'gpuRenderingVerified':False}
(out/'pack-audit.json').write_text(json.dumps(audit,indent=2));print(json.dumps({k:v for k,v in audit.items()if k not in['changedFiles','addedFiles']}))
