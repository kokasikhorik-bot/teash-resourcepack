Original model and texture: RayTrace082 / Untamed Wilds, GPL-3.0. https://github.com/RayTrace082/untamedwilds/tree/1.18.2
Adapted to multipart ItemDisplay assets for teash. Original hierarchy and UVs retained. Hammerhead and goblin-only head parts omitted.
