"""Outvoted GPL Barnacle to vanilla display bones, retaining original editable sources."""
from pathlib import Path
import json, shutil, hashlib
R=Path(__file__).resolve().parents[1]; S=R/'build/mob-a-v19/research'; P=R/'resourcepack'
g=json.loads((S/'barnacle.geo.json').read_text())['minecraft:geometry'][0]
tw=g['description']['texture_width'];th=g['description']['texture_height']; parts=[]
for b in g['bones']:
 if not b.get('cubes'):continue
 px,py,pz=b['pivot']; elements=[]
 for c in b['cubes']:
  assert 'rotation' not in c
  x,y,z=c['origin'];dx,dy,dz=c['size'];i=c.get('inflate',0);u,v=c['uv']
  uv={'east':[u,v+dz,u+dz,v+dz+dy],'south':[u+dz,v+dz,u+dz+dx,v+dz+dy],'west':[u+dz+dx,v+dz,u+2*dz+dx,v+dz+dy],'north':[u+2*dz+dx,v+dz,u+2*dz+2*dx,v+dz+dy],'up':[u+dz,v,u+dz+dx,v+dz],'down':[u+dz+dx,v,u+dz+2*dx,v+dz]}
  elements.append({'from':[-x-dx+px+8-i,y-py+8-i,-z-dz+pz+8-i],'to':[-x+px+8+i,y+dy-py+8+i,-z+pz+8+i],'faces':{f:{'uv':[n*16/(tw if j%2==0 else th) for j,n in enumerate(a)],'texture':'#mob',**({'rotation':180}if f in ['up','down']else{})}for f,a in uv.items()}})
 # Vanilla element coordinates must stay inside [-16,32]. Tentacles are 44px long.
 # Bake at quarter size and restore the factor in the display transform, preserving UVs and bone offsets.
 for e in elements:
  for k in ['from','to']:e[k]=[8+(v-8)/4 for v in e[k]]
  assert all(-16<=v<=32 for k in ['from','to'] for v in e[k])
 name=b['name']; parts.append(name)
 for kind,doc in [('models',{'credit':'Outvoted contributors / GPL-3.0; teash display conversion','textures':{'mob':'teash:item/mobs/barnacle','particle':'teash:item/mobs/barnacle'},'ambientocclusion':False,'elements':elements}),('items',{'model':{'type':'minecraft:model','model':'teash:mobs/barnacle-'+name}})]:
  f=P/f'assets/teash/{kind}/mobs/barnacle-{name}.json';f.parent.mkdir(parents=True,exist_ok=True);f.write_text(json.dumps(doc,indent=2))
shutil.copyfile(S/'barnacle.png',P/'assets/teash/textures/item/mobs/barnacle.png')
for n,doc in [('barnacle-rig.json',g['bones']),('barnacle-parts.json',parts)]: (R/'plugins-src/teash-testmobs'/n).write_text(json.dumps(doc,indent=2))
shutil.copyfile(S/'barnacle.animation.json',R/'plugins-src/teash-testmobs/barnacle-animations.json')
L=P/'licenses/outvoted-barnacle';L.mkdir(parents=True,exist_ok=True)
for n in ['barnacle.geo.json','barnacle.animation.json','barnacle.png','BarnacleModel.java','BarnacleRenderer.java','BarnacleEntity.java']:shutil.copyfile(S/n,L/n)
shutil.copyfile(R/'build/jaws-v8/research/LICENSE',L/'LICENSE')
shutil.copyfile(__file__,L/'import-mob-a-v19.py')
(L/'NOTICE.txt').write_text('Mob A / Barnacle: fan reconstruction by Outvoted contributors, How-Bout-No/Outvoted, GPL-3.0.\nSource commit f5b4c8cbcc981a884b75540a4c7875a97a98e5da, branch 1.17.1.\nNot an officially released Mojang model. Original geometry, texture and animations included.\nModified by teash: vanilla display conversion; original tentacle animation channels with faster swimming; live tongue geometry and server-controlled orientation.\nUnrelated resourcepack content retains its original authorship.\n')
print(json.dumps({'parts':parts,'cubes':sum(len(b.get('cubes',[])) for b in g['bones']),'texture':[tw,th],'sourceSha256':hashlib.sha256((S/'barnacle.geo.json').read_bytes()).hexdigest()}))
