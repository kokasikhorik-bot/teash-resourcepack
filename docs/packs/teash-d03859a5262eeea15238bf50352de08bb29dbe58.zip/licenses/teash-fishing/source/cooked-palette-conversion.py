"""Use ready-made Minecraft sprites; do not replace any vanilla sprite or model."""
from pathlib import Path
from io import BytesIO
import zipfile,json,hashlib,colorsys
from PIL import Image,ImageDraw,ImageFont
root=Path('updates/fishing-v1');sources=root/'sources'
archives={n:zipfile.ZipFile(sources/(n+'.jar')) for n in ['tide','gone-fishing','nether-depths-upgrade']}
with zipfile.ZipFile(root/'teash-resourcepack.zip') as z:files={n:z.read(n) for n in z.namelist() if not n.endswith('/')}
cat=json.loads((root/'catalog.json').read_text(encoding='utf8'))
names={
'river':['bluegill','white_crappie','carp','pike','yellow_perch','rainbow_trout','sturgeon'],
'ocean':['anchovy','mackerel','red_snapper','tuna','ocean_perch','sailfish','swordfish'],
'warm':['angelfish','blue_neonfish','guppy','mahi_mahi','aquathorn','radiant_guppy','midas_fish'],
'cold':['brook_trout','black_crappie','walleye','smallmouth_bass','mooneye','frostbite_flounder','neptune_koi'],
'swamp':['catfish','slimy_salmon','snook','arapaima','mirage_catfish','sleepy_carp','blossom_bass'],
'deep':['anglerfish','deep_grouper','coelacanth','lapis_lanternfish','deep_blue','abyss_angler','shadow_snapper'],
'cave':['cave_crawler','cave_eel','dripstone_darter','pale_clubfish','echo_snapper','crystalline_carp','glowfish'],
'lake':['largemouth_bass','flounder','amber_rockfish','stone_rockfish','violet_carp','gilded_minnow','magic_carp']}
gofish=['rainy_bass','nebula_swordfish','golden_fish','blizzard_bass','lilyfish','blackstone_trout','endfish','carrot_carp']
gofishru=['Дождевой окунь','Туманный меченосец','Золотая рыба','Вьюжный окунь','Кувшинковая рыба','Чернокаменная форель','Рыба Края','Морковный карп']
lang=json.loads(archives['tide'].read('assets/tide/lang/ru_ru.json'))
gamelang=json.loads(archives['tide'].read('assets/tide/lang/en_us.json'))
records=[]
def writepng(path,im):b=BytesIO();im.save(b,'PNG');files[path]=b.getvalue()
def copytexture(slug,original,id,derivative=False):
 b=archives[slug].read(original);dest='assets/teash/textures/fishing/'+id+'.png'
 if derivative:
  im=Image.open(BytesIO(b)).convert('RGBA');out=im.copy()
  for y in range(im.height):
   for x in range(im.width):
    r,g,bl,a=im.getpixel((x,y));lum=(.25*r+.57*g+.18*bl)/255
    if a:out.putpixel((x,y),(int(42+lum*190),int(22+lum*130),int(17+lum*64),a))
  writepng(dest,out)
 else:files[dest]=b
 if original+'.mcmeta' in archives[slug].namelist():files[dest+'.mcmeta']=archives[slug].read(original+'.mcmeta')
 records.append(dict(item=id,project=slug,original=original,adaptation='cooked palette; original silhouette and pixels retained' if derivative else 'unmodified PNG',sha256=hashlib.sha256(files[dest]).hexdigest()))
for i,f in enumerate(cat['fish']):
 hab=f['habitat'];j=f['shape'];g=list(names).index(hab);id=f['id']
 slug='tide' if j<7 else 'gone-fishing';ns='tide' if j<7 else 'gofish';name=names[hab][j] if j<7 else gofish[g]
 original=f'assets/{ns}/textures/item/{name}.png';copytexture(slug,original,id)
 f['name']=lang.get('item.tide.'+name,gamelang.get('item.tide.'+name,name.replace('_',' ').title())) if j<7 else gofishru[g]
 f['artSource']=slug;f['sourceSpecies']=name
 cooked_native={'rainy_bass':'steamed_bass','blackstone_trout':'grilled_blackstone_trout','endfish':'baked_endfish','carrot_carp':'baked_carrot_carp','tuna':'grilled_tuna'}.get(name)
 if cooked_native:copytexture(slug,f'assets/{ns}/textures/item/{cooked_native}.png',id+'_cooked')
 else:copytexture(slug,original,id+'_cooked',True)
rodnames=['wooden_fishing_rod','copper_fishing_rod','iron_fishing_rod','diamond_fishing_rod','breeze_fishing_rod','crystal_fishing_rod','neptunite_fishing_rod']
available=set(archives['tide'].namelist());fallback=['diamond_fishing_rod','ammonite_fishing_rod','blazing_fishing_rod','echo_fishing_rod','crystal_fishing_rod','breeze_fishing_rod','netherite_fishing_rod']
selected=[]
for n in rodnames:
 if f'assets/tide/textures/item/{n}.png' not in available:n=next(x for x in fallback if x not in selected and f'assets/tide/textures/item/{x}.png' in available)
 selected.append(n)
for i,n in enumerate(selected):
 id='rod_'+str(i);copytexture('tide',f'assets/tide/textures/item/{n}.png',id)
 cast=f'assets/tide/textures/item/{n}_cast.png'
 if cast in available:
  copytexture('tide',cast,id+'_cast');files[f'assets/teash/models/item/fishing/{id}_cast.json']=json.dumps({'parent':'minecraft:item/handheld_rod','textures':{'layer0':'teash:fishing/'+id+'_cast'}}).encode()
  files[f'assets/teash/items/fishing/{id}.json']=json.dumps({'model':{'type':'minecraft:condition','property':'minecraft:fishing_rod/cast','on_true':{'type':'minecraft:model','model':'teash:item/fishing/'+id+'_cast'},'on_false':{'type':'minecraft:model','model':'teash:item/fishing/'+id}}}).encode()
ndu=['baked_glowdine_stew','grilled_obsidianfish','searing_cod_roll','grilled_soulsucker','warped_kelp_roll','baked_magmacubefish_stew','baked_searing_cod_stew']
for i,n in enumerate(ndu):copytexture('nether-depths-upgrade','assets/netherdepthsupgrade/textures/item/farmersdelight_compat_food/'+n+'.png','dish_'+str(i+1))
for i,n in enumerate(['candied_smoked_salmon','endfish_and_chorus','aquatic_astral_stew'],8):copytexture('gone-fishing','assets/gofish/textures/item/'+n+'.png','dish_'+str(i))
for item,n in [('sonar','fish_finder'),('bait','bait'),('book','fishing_journal')]:copytexture('tide',f'assets/tide/textures/item/{n}.png',item)
# Preserve credits/licenses and exact upstream PNGs in the delivered pack, including MPL source form.
notice=[]
for slug in archives:
 metadata=json.loads((sources/(slug+'.json')).read_text(encoding='utf8'));notice.append(metadata)
 for path in sources.glob(slug+'-*'):
  if path.is_file():files['licenses/teash-fishing/'+path.name]=path.read_bytes()
 for r in records:
  if r['project']==slug:
   orig=r['original'];files['licenses/teash-fishing/source/'+slug+'/'+orig]=archives[slug].read(orig)
files['licenses/teash-fishing/credits.json']=json.dumps(notice,ensure_ascii=False,indent=2).encode()
files['licenses/teash-fishing/asset-map.json']=json.dumps(records,ensure_ascii=False,indent=2).encode()
files['licenses/teash-fishing/README.txt']=b'Tide 2 by Lightning64: MPL-2.0. Go Fish / Gone Fishing by Draylar and Patbox: MIT. Nether Depths Upgrade by Scouter567: MIT (official project license declaration). Only selected art assets are used; no mod code runs on the server. Unchanged upstream PNG source form and transformations are included here. Cooked palette adaptations are by teash.\n'
files['licenses/teash-fishing/source/cooked-palette-conversion.py']=Path(__file__).read_bytes()
atlas=json.loads(files['assets/minecraft/atlases/items.json']);existing={s.get('resource') for s in atlas['sources']}
for n in files:
 if n.startswith('assets/teash/textures/fishing/') and n.endswith('.png') and '/ui/' not in n:
  ref='teash:'+n.removeprefix('assets/teash/textures/').removesuffix('.png')
  if ref not in existing:atlas['sources'].append({'type':'single','resource':ref,'sprite':ref})
files['assets/minecraft/atlases/items.json']=json.dumps(atlas).encode()
(root/'catalog.json').write_text(json.dumps(cat,ensure_ascii=False,indent=2),encoding='utf8')
with zipfile.ZipFile(root/'teash-resourcepack.zip','w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for n,b in files.items():z.writestr(n,b)
sheet=Image.new('RGB',(768,704),'#102a3e');draw=ImageDraw.Draw(sheet)
font=ImageFont.truetype('C:/Windows/Fonts/arial.ttf',11)
for i,f in enumerate(cat['fish']):
 x,y=i%8*96,i//8*85
 for cooked in [False,True]:
  im=Image.open(BytesIO(files['assets/teash/textures/fishing/'+f['id']+('_cooked' if cooked else '')+'.png'])).convert('RGBA');im=im.crop((0,0,im.width,min(im.width,im.height)));im.thumbnail((40,40),Image.Resampling.NEAREST);im=im.resize((40,40),Image.Resampling.NEAREST);sheet.paste(im,(x+4+int(cooked)*44,y+2),im)
 words=f['name'];draw.text((x+2,y+44),words[:15],font=font,fill='#d5edef');draw.text((x+2,y+58),words[15:30],font=font,fill='#d5edef');draw.text((x+2,y+71),f['artSource'],font=font,fill='#64b9c3')
sheet.save(root/'fish-preview.png')
audit=json.loads((root/'pack-audit.json').read_text(encoding='utf8'));audit.update(readyMadeFishTextures=64,projects=list(archives),upstreamRecords=len(records),cookedAdaptations=sum('cooked palette' in r['adaptation'] for r in records),sha1=hashlib.sha1((root/'teash-resourcepack.zip').read_bytes()).hexdigest());(root/'pack-audit.json').write_text(json.dumps(audit,indent=2),encoding='utf8');(root/'asset-map.json').write_text(json.dumps(records,ensure_ascii=False,indent=2),encoding='utf8');print(json.dumps(audit))
