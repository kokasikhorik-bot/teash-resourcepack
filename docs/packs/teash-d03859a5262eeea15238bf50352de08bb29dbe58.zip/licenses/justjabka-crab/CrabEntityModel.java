package justjabka.crab.entity.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.model.*;
import net.minecraft.client.render.entity.animation.Animation;
import net.minecraft.client.render.entity.model.EntityModel;
import net.minecraft.client.render.entity.model.ModelTransformer;

@Environment(EnvType.CLIENT)
public class CrabEntityModel extends EntityModel<CrabEntityRenderState> {
    private final ModelPart crab = this.root.getChild("crab");
    private final ModelPart bigClaw = this.crab.getChild("big_claw");
    private final Animation walkingAnimation;
    private final Animation idlingAnimation;

    public static final ModelTransformer BABY_TRANSFORMER = ModelTransformer.scaling(0.6F);

    public CrabEntityModel(ModelPart modelPart) {
        super(modelPart);
        this.walkingAnimation = CrabAnimations.WALKING.createAnimation(modelPart);
        this.idlingAnimation = CrabAnimations.IDLING.createAnimation(modelPart);
    }

    public static TexturedModelData getTexturedModelData() { return TexturedModelData.of(getModelData(), 64, 64); }

    protected static ModelData getModelData() {
        ModelData modelData = new ModelData();
        ModelPartData modelPartData = modelData.getRoot();
        ModelPartData crab = modelPartData.addChild("crab", ModelPartBuilder.create().uv(0, 0).cuboid(-4.5F, -2.5848F, -8.7035F, 9.0F, 4.0F, 8.0F, new Dilation(0.0F)).uv(0, 26).cuboid(-4.5F, -4.0848F, -8.7535F, 3.0F, 3.0F, 0.0F, new Dilation(0.0F)).uv(6, 26).cuboid(1.5F, -4.0848F, -8.7535F, 3.0F, 3.0F, 0.0F, new Dilation(0.0F)), ModelTransform.origin(0.0F, 21.0848F, 4.7035F));
        ModelPartData cube_r1 = crab.addChild("cube_r1", ModelPartBuilder.create().uv(26, 26).cuboid(1.0F, -1.0F, 0.0F, 1.0F, 3.0F, 0.0F, new Dilation(0.0F)).uv(24, 26).cuboid(-1.0F, -1.0F, 0.0F, 1.0F, 3.0F, 0.0F, new Dilation(0.0F)), ModelTransform.of(-0.5F, -2.5848F, -8.7035F, -0.3927F, 0.0F, 0.0F));
        ModelPartData right_leg = crab.addChild("right_leg", ModelPartBuilder.create().uv(24, 20).cuboid(-4.0F, 0.0F, -0.5F, 4.0F, 0.0F, 1.0F, new Dilation(0.0F)).uv(24, 21).cuboid(-4.0F, 0.0F, 2.0F, 4.0F, 0.0F, 1.0F, new Dilation(0.0F)).uv(24, 22).cuboid(-4.0F, 0.0F, -3.0F, 4.0F, 0.0F, 1.0F, new Dilation(0.0F)), ModelTransform.of(-4.5F, 0.4152F, -4.7035F, 0.0F, 0.0F, -0.6981F));
        ModelPartData left_leg = crab.addChild("left_leg", ModelPartBuilder.create().uv(24, 23).cuboid(0.0F, 0.0F, -0.5F, 4.0F, 0.0F, 1.0F, new Dilation(0.0F)).uv(24, 24).cuboid(0.0F, 0.0F, 2.0F, 4.0F, 0.0F, 1.0F, new Dilation(0.0F)).uv(24, 25).cuboid(0.0F, 0.0F, -3.0F, 4.0F, 0.0F, 1.0F, new Dilation(0.0F)), ModelTransform.of(4.5F, 0.4152F, -4.7035F, 0.0F, 0.0F, 0.6981F));
        ModelPartData big_claw = crab.addChild("big_claw", ModelPartBuilder.create().uv(0, 20).cuboid(0.75F, 0.75F, -1.9988F, 8.0F, 2.0F, 4.0F, new Dilation(0.0F)).uv(12, 26).cuboid(0.75F, -1.25F, -2.0038F, 3.0F, 2.0F, 0.0F, new Dilation(0.0F)).uv(18, 26).cuboid(0.75F, -1.25F, 2.0012F, 3.0F, 2.0F, 0.0F, new Dilation(0.0F)), ModelTransform.of(-11.75F, -2.9598F, -8.9547F, 0.3761F, 0.3875F, 0.2784F));
        ModelPartData top = big_claw.addChild("top", ModelPartBuilder.create().uv(0, 12).cuboid(0.0F, -4.0F, -2.0F, 8.0F, 4.0F, 4.0F, new Dilation(0.0F)), ModelTransform.origin(0.75F, 0.75F, 0.0012F));
        ModelPartData little_claw = crab.addChild("little_claw", ModelPartBuilder.create().uv(24, 12).cuboid(-5.79F, -2.922F, -1.8877F, 5.0F, 4.0F, 4.0F, new Dilation(0.0F)), ModelTransform.of(8.5F, -0.0848F, -9.3785F, 0.2317F, -0.4876F, -0.1746F));
        return modelData;
    }

    public void setAngles(CrabEntityRenderState crabEntityRenderState) {
        super.setAngles(crabEntityRenderState);

        // Animations
        this.walkingAnimation.applyWalking(crabEntityRenderState.limbSwingAnimationProgress, crabEntityRenderState.limbSwingAmplitude, 2.0F, 2.5F);
        this.idlingAnimation.apply(crabEntityRenderState.idlingAnimationState, crabEntityRenderState.age, 1.0F);

        this.bigClaw.visible = !crabEntityRenderState.baby; // Hide bigClaw if crab is baby
    }
}