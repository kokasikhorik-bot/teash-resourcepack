from pathlib import Path
import json,shutil,zipfile
R=Path('.');S=R/'build/wildfire-v23/research';P=R/'resourcepack';O=R/'updates/wildfire-v23';O.mkdir(parents=True,exist_ok=True)
g=json.loads((S/'wildfire.geo.json').read_text())['minecraft:geometry'][0];tw=g['description']['texture_width'];th=g['description']['texture_height'];parts=[]
for b in g['bones']:
 if not b.get('cubes'):continue
 px,py,pz=b['pivot'];elements=[]
 for c in b['cubes']:
  assert 'rotation'not in c;x,y,z=c['origin'];dx,dy,dz=c['size'];i=c.get('inflate',0);u,v=c['uv'];uv={'east':[u,v+dz,u+dz,v+dz+dy],'south':[u+dz,v+dz,u+dz+dx,v+dz+dy],'west':[u+dz+dx,v+dz,u+2*dz+dx,v+dz+dy],'north':[u+2*dz+dx,v+dz,u+2*dz+2*dx,v+dz+dy],'up':[u+dz,v,u+dz+dx,v+dz],'down':[u+dz+dx,v,u+dz+2*dx,v+dz]};elements.append({'from':[-x-dx+px+8-i,y-py+8-i,-z-dz+pz+8-i],'to':[-x+px+8+i,y+dy-py+8+i,-z+pz+8+i],'faces':{f:{'uv':[n*16/(tw if j%2==0 else th)for j,n in enumerate(a)],'texture':'#mob',**({'rotation':180}if f in ['up','down']else{})}for f,a in uv.items()}})
 assert all(-16<=v<=32 for e in elements for k in ['from','to']for v in e[k]);name=b['name'];parts.append(name)
 for kind,doc in [('models',{'credit':'Outvoted contributors / GPL-3.0; teash display conversion','textures':{'mob':'teash:item/mobs/wildfire','particle':'teash:item/mobs/wildfire'},'ambientocclusion':False,'elements':elements}),('items',{'model':{'type':'minecraft:model','model':'teash:mobs/wildfire-'+name}})]:
  f=P/f'assets/teash/{kind}/mobs/wildfire-{name}.json';f.parent.mkdir(parents=True,exist_ok=True);f.write_text(json.dumps(doc,indent=2),'utf-8')
shutil.copyfile(S/'wildfire.png',P/'assets/teash/textures/item/mobs/wildfire.png');(R/'plugins-src/teash-testmobs/wildfire-rig.json').write_text(json.dumps(g['bones'],indent=2),'utf-8');shutil.copyfile(S/'wildfire.animation.json',R/'plugins-src/teash-testmobs/wildfire-animations.json')
L=P/'licenses/outvoted-wildfire';L.mkdir(parents=True,exist_ok=True)
for name in ['wildfire.geo.json','wildfire.animation.json','wildfire.png','WildfireEntity.java']:shutil.copyfile(S/name,L/name)
shutil.copyfile(R/'build/jaws-v8/research/LICENSE',L/'LICENSE');shutil.copyfile(__file__,L/'import-wildfire-v23.py');(L/'NOTICE.txt').write_text('Wildfire fan recreation by Outvoted contributors, How-Bout-No/Outvoted, GPL-3.0.\nhttps://github.com/How-Bout-No/Outvoted/tree/f5b4c8cbcc981a884b75540a4c7875a97a98e5da\nOriginal geometry, textures and animation channels retained.\nModified by teash: vanilla display conversion, four destructible shield segments, fire wave, fortress encounter registry and shield enchantment reward. Not an official Mojang model.\n','utf-8')
pack={'pack':{'description':'teash • Wildfire shield enchantment','pack_format':107,'min_format':[107,1],'max_format':[107,1]}}
enchant={'description':{'text':'Пламенный отпор','color':'#B33657','font':'teash:small'},'supported_items':'minecraft:shield','weight':1,'max_level':1,'min_cost':{'base':25,'per_level_above_first':0},'max_cost':{'base':50,'per_level_above_first':0},'anvil_cost':8,'slots':['mainhand','offhand'],'effects':{}}
with zipfile.ZipFile(O/'teash-wildfire.zip','w',zipfile.ZIP_DEFLATED)as z:
 z.writestr('pack.mcmeta',json.dumps(pack));z.writestr('data/teash/enchantment/blazing_retaliation.json',json.dumps(enchant,ensure_ascii=False))
print(json.dumps({'modelParts':parts,'enchantment':'teash:blazing_retaliation'}))
