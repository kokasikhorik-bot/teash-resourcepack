"""Convert GPL Outvoted/Glutton bones and box UVs into vanilla item-display parts."""
from pathlib import Path
import json,shutil,hashlib
root=Path(__file__).resolve().parents[1];src=root/'build/jaws-v8/research';pack=root/'resourcepack'
doc=json.loads((src/'glutton.geo.json').read_text());geo=doc['minecraft:geometry'][0];tw=geo['description']['texture_width'];th=geo['description']['texture_height'];parts=[]
mapping={'top':'upper','bottom':'lower','body':'body','LegFR':'legfr','LegFL':'legfl','LegBR':'legbr','LegBL':'legbl'}
for bone in geo['bones']:
 if bone['name'] not in mapping:continue
 name=mapping[bone['name']];px,py,pz=bone['pivot'];elements=[]
 for c in bone['cubes']:
  x,y,z=c['origin'];dx,dy,dz=c['size'];i=c.get('inflate',0);u,v=c['uv']
  boxes={'east':[u,v+dz,u+dz,v+dz+dy],'south':[u+dz,v+dz,u+dz+dx,v+dz+dy],'west':[u+dz+dx,v+dz,u+2*dz+dx,v+dz+dy],'north':[u+2*dz+dx,v+dz,u+2*dz+2*dx,v+dz+dy],'up':[u+dz,v,u+dz+dx,v+dz],'down':[u+dz+dx,v,u+dz+2*dx,v+dz]}
  faces={face:{'uv':[a*16/(tw if n%2==0 else th) for n,a in enumerate(uv)],'texture':'#mob',**({'rotation':180}if face in ['up','down']else{})}for face,uv in boxes.items()}
  elements.append({'from':[-x-dx+px+8-i,y-py+8-i,-z-dz+pz+8-i],'to':[-x+px+8+i,y+dy-py+8+i,-z+pz+8+i],'faces':faces})
 model={'credit':'Outvoted / How-Bout-No; GPL-3.0; converted to vanilla display parts by teash','textures':{'mob':'teash:item/mobs/jaws-outvoted','particle':'teash:item/mobs/jaws-outvoted'},'ambientocclusion':False,'elements':elements}
 for kind,value in [('models',model),('items',{'model':{'type':'minecraft:model','model':'teash:mobs/jaws-'+name}})]:
  target=pack/f'assets/teash/{kind}/mobs/jaws-{name}.json';target.parent.mkdir(parents=True,exist_ok=True);target.write_text(json.dumps(value,indent=2),encoding='utf-8')
 parts.append({'name':name,'x':-px/16,'y':py/16,'z':-pz/16})
target=pack/'assets/teash/textures/item/mobs/jaws-outvoted.png';target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src/'glutton.png',target)
(root/'plugins-src/teash-testmobs/model-parts.json').write_text(json.dumps(parts,indent=2),encoding='utf-8')
origin=json.loads((src/'origin.json').read_text());origin.update({'officialConcept':'https://www.minecraft.net/en-us/article/meet-mob-c','note':'Fan reconstruction from Outvoted, not an official released Mojang 3D asset. Coordinates, box UVs and bone pivots converted; runtime walk, bite and burrow animation by teash.','parts':parts,'sourceSha256':hashlib.sha256((src/'glutton.geo.json').read_bytes()).hexdigest()})
licenses=pack/'licenses/outvoted-jaws';licenses.mkdir(parents=True,exist_ok=True)
for name in ['LICENSE','glutton.geo.json','glutton.animation.json','glutton.png','origin.json']:shutil.copyfile(src/name,licenses/name)
shutil.copyfile(Path(__file__),licenses/'import-jaws-v8.py')
(licenses/'NOTICE.txt').write_text('Great Hunger / Glutton model and texture: Outvoted contributors, How-Bout-No/Outvoted, GPL-3.0.\nSource branch 1.17.1, commit '+origin['commit']+'.\nThis is a fan reconstruction of Mojang Mob C, not an official Mojang 3D release.\nModified by teash: converted bones and box UVs to vanilla item-display JSON; separate walking legs and jaws.\nOriginal editable geometry, texture, animations, conversion script and GPL license accompany this pack.\nLicense applies to this adaptation; unrelated pack artwork retains its original authorship.\n',encoding='utf-8')
(root/'data/jaws-v8-assets.json').write_text(json.dumps(origin,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps({'parts':len(parts),'cubes':sum(len(b.get('cubes',[]))for b in geo['bones']),'source':origin['commit']}))
